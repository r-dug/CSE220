

    import java.util.Scanner;
    import java.util.Arrays;
    /**
     * The NumericData class maintains an array of numeric information, and 
     * permits the user to print some simple summary information.
     *
     * @author Andrew Karem
     * 
     */
    public class NumericData
    {    
        private double[] data = new double[100]; //The actual numeric data is stored here    
        int arraysize;
        /* NumericData() constructs a new NumericData object using keyboard input.  Values are 
         * appended so long as they are valid real numbers, at which point construction terminates.
         */
        public NumericData() 
        {
            arraysize=0;        
            Scanner in = new Scanner(System.in);
            while(true)
            {
                //get user input
                try
                {
                    double num = Double.parseDouble(in.nextLine());
                    data[arraysize]=num;
                    arraysize++;
                }
                catch(NumberFormatException e)
                {
                    System.out.println("Non-numeric data entered");
                    break;
                }
    
            }
        }
        
        /*printElements() prints the elements of the stored data with white space separation.
         */
        public void printElements() 
        {
            for (int i = 0; i < arraysize; i++) 
            {
                System.out.print(data[i]+ " ");
            }
            System.out.println("");
        }
       
    
        /* printExtreme() prints the minimum and maximum data elements.
         */
        public void printExtrema() 
        {
            double minEl=Double.MAX_VALUE;
            double maxEl=Double.MIN_VALUE;
            for (int i = 0; i < arraysize; i++) {
                if (data[i]<minEl) { minEl=data[i];}
                if (data[i]>maxEl) { maxEl=data[i];}    
            }
            System.out.println("The minimum array value is " + minEl +  
                               " and the max value is " + maxEl +".");
        }

       /* printMean() prints the average of the array values.
        */
       public void printMean() 
       {
           double sum=0;
           for (int i = 0; i < arraysize; i++) {
               sum+=data[i];    
           }
           System.out.println("The average array value is " + sum/arraysize +".");
       }

       /* the main function creates a sample NumericData object and prints relevant summary info.
        */
       public static void main(String[] args)
       {
           NumericData sampnd=new NumericData();
           sampnd.printElements();
           sampnd.printExtrema();
           sampnd.printMean();
       }
    }
