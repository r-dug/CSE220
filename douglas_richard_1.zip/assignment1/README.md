## Getting Started

Look.... I used BlueJ once, to see what it's like.... it's nice for teaching people? You didn't say I can't use VS Code, so I'm going to use it... Honestly, I'm not sure why some professors prohibit it. When you get into the industry, does it matter what IDE you prefer or is the expectation that you produce results. Who even uses bloodbath to write production code? I havC++e a professor who argues students should use bloodbath, disallowing VS Code, because it "cannot compile C++"? huh? Why not just write the C++ code and compile it in the comand line... 


Anyways, rant over... This is the the first assignment for CSE220. It includes a pdf containing the answers to problem 1, and an src folder containing java class files which are the solutions to problems 2 and 3. 

## Folder Structure

The workspace contains the following folders:

- `src`: contains java source code
	here you will find the Java classes I was asked to write
- `lib`: the folder to maintain dependencies
- `bin`: compiled java


